$(document).ready(function () {
  function fetchData(filename, result) {
    $.ajax({
      url: "data/" + filename,
      method: "get",
      dataType: "json",
      success: result,
      error: function (xhr) {
        var message = "";
        var divZaGresku = document.getElementById("greska");
        if (xhr.status == 0) {
          message = "Verify your network connection";
        } else if (xhr.status == 500) {
          message = "Page not found";
        } else if (xhr.status == 404) {
          message = "Page not fount";
        } else {
          message = "Uncaught error";
        }
        $(divZaGresku).html(message);
      },
    });
  }

  $("#sort").change(promenaFiltera);
  $("#pisci").change(promenaFiltera);

  function promenaFiltera() {
    fetchData("proizvodi.json", function (result) {
      ispisKnjiga(result);
    });
  }

  // zahtev za navigacioni meni
  fetchData("meni.json", function (result) {
    // console.log(result)
    ispisNav(result);
  });

  //zahtev za ispisivanje zanrova u checkboxu
  fetchData("proizvodi.json", function (result) {
    ispisKnjiga(result);
    // sortiranje(result);
    setLS("sviProizvodi", result);
  });

  //zahteva za pisce
  fetchData("pisci.json", function (result) {
    ispisPisaca(result);
  });

  fetchData("zanrovi.json", function (result) {
    obradaZanrova(result);
  });

  fetchData("zanrovi.json", function (result) {
    ispisZanrova(result);
  });

  fetchData("footer_menu.json", function (result) {
    ispisFotera(result);
  });
});

//funckija za ispisvanje navigacije
function ispisNav(linkoviNiz) {
  let html = "";
  let divMeni = document.querySelector("#meni");
  // console.log(divMeni);
  for (let link of linkoviNiz) {
    html += `<li><a href="${link.href}">${link.text}</a></li>`;
  }
  $(divMeni).html(html);
}
//funckija za ispis footera
function ispisFotera(footerNiz) {
  let html = "<ul>";
  let div = $("#footer-nav");
  //let divFooter = document.getElementById("footer-nav");
  //let divFooter = $("#footer-nav");
  for (let foot of footerNiz) {
    html += `<li><a href="${foot.href}"><i class="${foot.icon}" aria-hidden="true"></i></a></li>`;
  }
  html += `</ul>`;
  $(div).html(html);
}
//fukcija za ispisivanje zanra u proizvodu
function obradaZanrova(zanroviNiz) {
  //console.log(zanroviNiz);
  let html = "";
  zanroviNiz?.forEach((zanr, x) => {
    x == 0 ? (html += zanr.naziv) : (html += ", " + zanr.naziv);
  });
  return html;
}
// fukcija za ispisivanje proizvoda u prodavnici
function ispisKnjiga(knjigeNiz) {
  knjigeNiz = sortiranje(knjigeNiz);
  knjigeNiz = pisacFilter(knjigeNiz);

  //console.log(knjigeNiz);
  let html = "";
  let knjigeDiv = document.querySelector("#knjige");
  if (knjigeNiz?.length === 0) {
    html = `<div class="product-grid" id="knjige">
            <h4>Nažalost trenutno nema proizvoda koje vi tražite.</h4>
            </div>`;
  } else {
    knjigeNiz?.forEach((k) => {
      let kategorija = k.kategorija.join(" ");
      let pisci = k.pisac.join(" ");
      let dostupno = k.raspolozivo;
      html += `
      
      <div class="product-item men ${kategorija} ${dostupno}" name="${pisci}">
       <div class="product discount product_filter">
       <div id="ispisPoruke" class="skrivenaPoruka"><h6>Proizvod je dodat u korpu.</h6></div>
      <div class="product_image">
        <img src="${k.slika.src}" alt="${k.slika.alt}">
      </div>
      <div class="product_info">
        <h5 class="product_name">${k.naslov}</h5>
        
        <div class="product_price"><b>${
          k.cena.novaCena
        }.00 din</b> 	&nbsp;	&nbsp;<s> ${
        k.cena.staraCena == "" ? "" : k.cena.staraCena + ".00"
      }</s></div>
      </div>
      </div>
      <input type="button" id="dugmeZaKorpu" class="red_button add_to_cart_button"  onclick='prikaziPoruku()' data-id=${
        k.id
      } value="Dodaj u korpu"/>
      
      </div>
      
   `;
    });
  }
  $(knjigeDiv).html(html);
  $(".add_to_cart_button").click(dodajUKopru);
}

//filtriranje pisaca
function pisacFilter(knjigeNiz) {
  let izabrano = [];
  $(".pisac:checked").each(function (el) {
    izabrano.push(parseInt($(this).val()));
  });
  if (izabrano.length != 0) {
    return knjigeNiz.filter((x) => izabrano.includes(x.pisac[0]));
  }
  return knjigeNiz;
}

function sortiranje(knjigeNiz) {
  //console.log(knjigeNiz);
  if (document.getElementById("sort") != null) {
    var tip = document.getElementById("sort").value;
    if (tip == 0) tip = "nazivASC";

    if (tip == "nazivASC") {
      return knjigeNiz.sort((k1, k2) => (k1.naslov > k2.naslov ? 1 : -1));
    }
    if (tip == "nazivDESC") {
      return knjigeNiz.sort((k1, k2) => (k1.naslov < k2.naslov ? 1 : -1));
    }
    if (tip == "cenaASC") {
      return knjigeNiz.sort((k1, k2) =>
        k1.cena.novaCena > k2.cena.novaCena ? 1 : -1
      );
    }
    if (tip == "cenaDESC") {
      return knjigeNiz.sort((k1, k2) =>
        parseInt(k1.cena.novaCena) < parseInt(k2.cena.novaCena) ? 1 : -1
      );
    }
  }
}

//funckija za prikaz zanrova
function ispisZanrova(zanroviNiz) {
  let html = "";
  // let divZanrovi = document.querySelector("#zanrovi");
  // console.log(zanroviNiz);
  zanroviNiz?.forEach((z) => {
    html += `<li class="list-group-item">
           <input type="checkbox" value="${z.id}" class="zanr" name="zanrovi" id="${z.id}"/> ${z.naziv}
        </li>`;
  });
  $("#zanrovi").html(html);
  //divZanrovi.innerHTML = html;
}

//funkcija za ispis pisaca
function ispisPisaca(pisciNiz) {
  //  console.log(pisciNiz);
  let html = "";
  pisciNiz?.forEach((p) => {
    html += `<li class="list-group-item">
           <input type="checkbox" value="${p.id}" class="pisac" name="pisci" id="${p.id}"/> ${p.ime} ${p.prezime}
        </li>`;
  });
  $("#pisci").html(html);
  // document.querySelector('#pisci').innerHTML = html;
}
function setLS(name, data) {
  localStorage.setItem(name, JSON.stringify(data));
}
//uzimanje iz ls
function getLS(name) {
  return JSON.parse(localStorage.getItem(name));
}
//dodavanje u korpu
function dodajUKopru() {
  //dodavanje u LS

  var knjigaId = $(this).data("id");
  //console.log(knjigaId);

  var knjigeUKorpi = getLS("korpa");
  //console.log(knjigeUKorpi);

  if (knjigeUKorpi == null) {
    dodajUKorpuPrvuKnjigu();
  } else {
    if (imaVecUKorpi()) uvecaj();
    else {
      nemaUKorpi();
    }
  }
  function dodajUKorpuPrvuKnjigu() {
    let knjigeIzKorpe = [];
    knjigeIzKorpe[0] = {
      id: knjigaId,
      kolicina: 1,
    };
    setLS("korpa", knjigeIzKorpe);
  }

  function imaVecUKorpi() {
    return knjigeUKorpi.filter((k) => k.id == knjigaId).length;
  }
  function uvecaj() {
    let knjigeIzKorpe = getLS("korpa");
    //console.log("usao");
    for (let k of knjigeIzKorpe) {
      //console.log(k);
      if (k.id == knjigaId) {
        //console.log(k.kolicina);
        k.kolicina++;
        break;
      }
    }
    setLS("korpa", knjigeIzKorpe);
  }

  function nemaUKorpi() {
    let knjigeIzKorpe = getLS("korpa");
    knjigeIzKorpe.push({
      id: knjigaId,
      kolicina: 1,
    });
    setLS("korpa", knjigeIzKorpe);
  }
}
let knjigeIzKorpe = getLS("korpa");
if (knjigeIzKorpe == null) {
  prikazPrazneKorpe();
} else {
  prikazKorpe();
}
//prazna Korpa
function prikazPrazneKorpe() {
  let html = `<div class="row">
              <div class="col-12 d-flex justify-content-around  ">
              <h2>Vasa korpa je trenutno prazna</h2>
              <a href="prodavnica.html" class="text-dark">Povratak na kupovinu</a>
              </div>
            
              </div>`;
  $("#prikaz").html(html);
}
//proizvodi iz korpe
function prikazKorpe() {
  let sveKnjige = getLS("sviProizvodi");
  //console.log(sveKnjige);
  var sveKnjigeIzKorpe = getLS("korpa");

  let knjigePikaz = sveKnjige.filter((k) => {
    for (let kLS of sveKnjigeIzKorpe) {
      if (k.id == kLS.id) {
        k.kolicina = kLS.kolicina;
        return true;
      }
    }
    return false;
  });
  ispisKorpe(knjigePikaz);
}

function ispisKorpe(knjige) {
  let html = `<table width="100%"  id="tabela">
            <thead background-color="grey" padding="10px">
              <tr>
               
                <th>Naslov</th>
               
                <th>Kolicina</th>
                <th>Povećaj količinu</th>
                <th>Cena</th>
                <th>Ukupna Cena</th>
                <th>Ukloni<th>
              </tr>
              </thead>
              <tbody>`;

  for (let k of knjige) {
    html += redTabele(k);
  }
  html += `</tbody></table>
  </br>
  
  <div class="d-flex align-items-center justify-content-end my-3">
  <input type="button" class="btn btn-success mx-4" name="potvrdi" onclick='potvrdi()'  id="potvrdi" value="Potvrdi"/>
  <input type="button" class="btn btn-danger" name="odustani" onclick="odustani()" id="odustani" value="Odustani"/>`;
  $("#prikaz").html(html);

  function redTabele(k) {
    return `<tr >
   
    <td class="invert">${k.naslov}</td>
    <td>${k.kolicina}</td>
    <td>  <div class="rem">
    <div class=""><button class="btn btn-secondary py-1 my-1"onclick='povecaj(${
      k.id
    })'>Povećaj</button> </div>
</div>
</td>
    <td >${k.cena.novaCena}</td>
    <td >${k.cena.novaCena * k.kolicina}</td>
    <td >
                <div class="rem">
                    <div class=""><button class="btn btn-dark py-1 my-1"onclick='ukolniizKorpe(${
                      k.id
                    })'>Ukolni</button> </div>
                </div>
            </td>
            </tr>
             
          `;
  }
}

function ukolniizKorpe(id) {
  let knjigeIzKorpe = getLS("korpa");
  let filtrirani = knjigeIzKorpe.filter((k) => k.id != id);
  setLS("korpa", filtrirani);
  prikazKorpe();
}
function povecaj(id) {
  let knjigeIzKorpe = getLS("korpa");
  //console.log("usao");
  console.log(knjigeIzKorpe);
  for (var k of knjigeIzKorpe) {
    if (k.id == id) {
      k.kolicina++;
    }
  }
  setLS("korpa", knjigeIzKorpe);
  prikazKorpe();
}
function odustani() {
  localStorage.removeItem("korpa");
  $("#tabela").css("display", "none");
  $("#racun").css("display", "none");
  $("#potvrdi").css("display", "none");
  $("#odustani").css("display", "none");
  let html = `<div class="row">
              <div class="col-12 d-flex justify-content-around  ">
              <h2>Vasa korpa je trenutno prazna</h2>
              <a href="prodavnica.html">Povratak na kupovinu</a>
              </div>
            
              </div>`;
  $("#prikaz").html(html);
  prikazKorpe();
}
function potvrdi() {
  var html = "";
  var divUspesno = document.querySelector("#uspesno");
  html += `
  <h4 class="text-success" >Uspešno ste izvršili kupovinu</h4>`;
  $(divUspesno).html(html);
}
//pronalazak po imenu
$("#pronadji").keyup(function () {
  const value = $(this).val().toLowerCase();

  $(".product-item").each(function () {
    //console.log($(this));
    const searchItem = $(this).text().toLowerCase();

    // return podaci.filter(x=> x.naslov.toLowerCase().indexOf(pretragaValue) !== -1)

    if (searchItem.indexOf(value) !== -1) {
      $(this).show();
      //console.log($(this).show().length);
      //console.log(" RADI");
    } else {
      $(this).hide();
      // console.log($(this).length);
      //console.log("NE RADI");
    }
  });
});
//zanrovi
$("#zanrovi").on("click", function () {
  var $posts = $(".product-item").hide();
  var $zanr = $(".zanr:checked");

  //console.log($posts);
  $posts
    .filter(function () {
      var $post = $(this);
      return $zanr.toArray().every(function (element) {
        return $post.hasClass($(element).attr("id"));
      });
    })
    .show();
});
//autori
$("#pisci").on("click", function () {
  var $posts = $(".product-item").hide();
  var $pisac = $(".pisac:checked");

  $posts
    .filter(function () {
      var $post = $(this);
      return $pisac.toArray().every(function (element) {
        return $post.attr("name") === $(element).attr("id");
      });
    })
    .show();
});
//dostupno
$("#dostupno").on("click", function () {
  var $posts = $(".product-item").hide();
  var $dostupno = $(".dostupno:checked");

  // console.log("a");
  $posts
    .filter(function () {
      var $post = $(this);
      return $dostupno.toArray().every(function (element) {
        return $post.hasClass($(element).attr("id"));
      });
    })
    .show();
});

//regularni izrazi

const dugme = document.querySelector("#btnProvera");
dugme?.addEventListener("click", function (e) {
  e.preventDefault();
  var regIme = /^[A-ZŠĐČĆŽ]{1}[a-zšđčćž]{2,12}(\s[A-Z]{1}[a-z]{1,11})?$/;
  var regPrezime = /^[A-ZŠĐČĆŽ]{1}[a-zšđčćž]{2,12}(\s[A-Z]{1}[a-z]{1,11})?$/;
  var regEmail = /^[a-z][\w\.\-]+\@[a-z0-9]{2,7}(\.[a-z]{2,4})?\.[a-z]{2,4}$/;
  var regTelefon = /^(\+381 6)[0-9]{1}[0-9]{3}[0-9]{4}$/;
  var regPoruka = /^([\w\.\-\s]{1,400})+$/;
  const ime = document.forma.ime.value;
  const prezime = document.forma.prezime.value;
  const email = document.forma.email.value;
  const telefon = document.forma.tel.value;
  const poruka = document.forma.poruka.value;

  if (
    !$("#opcija1").is(":checked") ||
    !$("#opcija2").is(":checked") ||
    !$("#opcija3").is(":checked")
  ) {
    $("#provera").removeClass("nePrikazi");
  }
  if (ime == "" || !ime.match(regIme)) {
    $(".greskaIme").addClass("greska");
  } else {
    $(".greskaIme").removeClass("greska");
  }
  if (prezime == "" || !prezime.match(regPrezime)) {
    $(".greskaPrezime").addClass("greska");
  } else {
    $(".greskaPrezime").removeClass("greska");
  }
  if (telefon == "" || !telefon.match(regTelefon)) {
    $(".greskaTelefon").addClass("greska");
  } else {
    $(".greskaTelefon").removeClass("greska");
  }
  if (email == "" || !email.match(regEmail)) {
    $(".greskaEmail").addClass("greska");
  } else {
    $(".greskaEmail").removeClass("greska");
  }
  if (poruka == "" || !poruka.match(regPoruka)) {
    $(".greskaPoruka").addClass("greska");
  } else {
    $(".greskaPoruka").removeClass("greska");
  }

  if (
    ($("#opcija1").is(":checked") ||
      $("#opcija2").is(":checked") ||
      $("#opcija3").is(":checked")) &&
    ime.match(regIme) &&
    prezime.match(regPrezime) &&
    telefon.match(regTelefon) &&
    email.match(regEmail) &&
    poruka.match(regPoruka)
  ) {
    $("#done").removeClass("skriveno");
    $("#error").addClass("skriveno");

    $("#provera").addClass("skriveno");
    return true;
  } else {
    $("#error").removeClass("skriveno");
    $("#done").addClass("skriveno");
    $("#provera").removeClass("skriveno");
    return false;
  }
});

function prikaziPoruku() {
  let poruka = $("#ispisPoruke");

  poruka.removeClass("skrivenaPoruka");
  setTimeout(function () {
    poruka.addClass("skrivenaPoruka");
  }, 2000);
}
